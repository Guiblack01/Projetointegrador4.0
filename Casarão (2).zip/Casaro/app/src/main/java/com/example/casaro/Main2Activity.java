package com.example.casaro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Main2Activity extends AppCompatActivity {

    private ImageButton botaoLivro;
    private ImageButton botaoMesusLivros;
    private ImageButton botaoEventos;
    private Button btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        botaoLivro = (ImageButton) findViewById(R.id.livros);
        botaoLivro.setOnClickListener(clickLivro);
//        -------------------------------------------------
        btnSair = (Button) findViewById(R.id.sair);
        btnSair.setOnClickListener(clickSair);
    }

    View.OnClickListener clickLivro = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent livro = new Intent(Main2Activity.this, Lista.class);
            startActivity(livro);
        }
    };

    View.OnClickListener clickSair = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };

}
