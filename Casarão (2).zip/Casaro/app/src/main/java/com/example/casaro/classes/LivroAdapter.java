package com.example.casaro.classes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.casaro.R;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class LivroAdapter extends ArrayAdapter<Livro> {

    private Context context;
    private ArrayList<Livro> elementos;

    public LivroAdapter( Context context, ArrayList<Livro> elementos){
        super(context, R.layout.linha, elementos);
        this.context = context;
        this.elementos = elementos;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.linha, parent, false);
        TextView nomeLivro =  v.findViewById(R.id.nomeLivro);
        TextView nomeAutor =  v.findViewById(R.id.nomeAutor);
        ImageView imagem = v.findViewById(R.id.imagem);

        nomeLivro.setText(elementos.get(position).getNomeLivro());
        nomeAutor.setText(elementos.get(position).getNomeAutor());
        imagem.setImageResource(elementos.get(position).getImagem());

        return v;
    }


}
