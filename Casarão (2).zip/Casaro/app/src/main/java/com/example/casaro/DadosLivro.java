package com.example.casaro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DadosLivro extends AppCompatActivity {

    Button voltarbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dados_livro);
        voltarbtn = findViewById(R.id.dadosVoltar);
        voltarbtn.setOnClickListener(voltarClick);
    }

    View.OnClickListener voltarClick = new View.OnClickListener() {
        //        @Override
//        public void onClick(View view) {
//            Intent novajanela = new Intent(DadosLivro.this, Lista.class);
//            startActivity(novajanela);
//        }
//    };
        @Override
        public void onClick (View v) {
            finish(); // Finaliza essa activity e volta para anterior
        }
    };
}
