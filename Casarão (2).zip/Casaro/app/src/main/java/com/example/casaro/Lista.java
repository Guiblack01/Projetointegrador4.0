package com.example.casaro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.casaro.classes.LivroAdapter;
import com.example.casaro.classes.Livro;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Lista extends AppCompatActivity {
    ListView listV_dados;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    private  List<Livro> listLivro = new ArrayList<Livro>();
    private ArrayAdapter<Livro> arrayAdapterLivro;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        listV_dados = (ListView) findViewById(R.id.lvLivro);

        inicializarFirebase();
        eventoDatabase();

    }

    private void eventoDatabase() {
        databaseReference.child("Livros").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listLivro.clear();
                for(DataSnapshot elementoSnapshot: dataSnapshot.getChildren()){
                    Livro l = elementoSnapshot.getValue(Livro.class);
                    listLivro.add(l);
                }
                arrayAdapterLivro = new ArrayAdapter<Livro>(Lista.this, android.R.layout.simple_list_item_1, listLivro);

                listV_dados.setAdapter(arrayAdapterLivro);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void inicializarFirebase() {
        FirebaseApp.initializeApp(Lista.this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }


}
