package com.example.casaro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText edUsuario;
    private EditText edSenha;
    private Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(clickLogin);
        edSenha = findViewById(R.id.edSenha);
        edUsuario = findViewById(R.id.edUsuario);
        btnLogin.setOnClickListener(clickLogin);
    }

    View.OnClickListener clickLogin = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(edUsuario.getText().toString().equals("admin") && edSenha.getText().toString().equals("123")){
                Intent novajanela = new Intent(MainActivity.this, Lista.class);
                Toast.makeText(getBaseContext(),"Confirmado Acesso.", Toast.LENGTH_LONG).show();
                startActivity(novajanela);
                edUsuario.setText("");
                edSenha.setText("");
            }else{
                Toast.makeText(getBaseContext(),"Senha ou Usuario Invalido.", Toast.LENGTH_LONG).show();
            }
        }
    };

//    public void checar(){
//        if(edUsuario.getText().toString().equals("admin") && edSenha.getText().toString().equals("123")){
//            btnLogin.setOnClickListener(clickLogin);
//            Toast.makeText(getBaseContext(),"Confirmado Acesso.", Toast.LENGTH_LONG).show();
//        }else{
//            Toast.makeText(getBaseContext(),"Senha ou Usuario Invalido.", Toast.LENGTH_LONG).show();
//        }
//    }
}
