package com.example.casaro.classes;

public class Livro {

    String nomeLivro;
    String nomeAutor;
    int imagem;


    public Livro(String nomeLivro, String nomeAutor, int imagem){
        this.nomeLivro = nomeLivro;
        this.nomeAutor = nomeAutor;
        this.imagem = imagem;
    }

    public int getImagem() {
        return imagem;
    }

    public void setImagem(int imagem) {
        this.imagem = imagem;
    }

    public String getNomeAutor() {
        return nomeAutor;
    }

    public void setNomeAutor(String nomeAutor) {
        this.nomeAutor = nomeAutor;
    }

    public String getNomeLivro() {
        return nomeLivro;
    }

    public void setNomeLivro(String nomeLivro) {
        this.nomeLivro = nomeLivro;
    }
}
